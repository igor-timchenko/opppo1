enum PostgresErrorCode {
    UniqueViolation = 'P2002',
  }
  
  export default PostgresErrorCode;
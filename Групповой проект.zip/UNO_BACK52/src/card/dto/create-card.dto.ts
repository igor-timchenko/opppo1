export class CreateCardDto {
    color: string;
    value: string;
}
